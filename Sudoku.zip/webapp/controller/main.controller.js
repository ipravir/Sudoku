sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("Sudoku.controller.main", {

		close_app: function(oEvent) {

			jQuery.sap.require("sap.m.MessageBox");
			sap.m.MessageBox.show(
				"Thank you for using the application!!!", {
					icon: sap.m.MessageBox.Icon.INFORMATION,
					title: "Thank You!!",
					actions: sap.m.MessageBox.Action.OK,
					onClose: function(oAction) {
						window.close();
					}
				}
			);
		},

		get_app_obj: function(AppID) {
			return sap.ui.getCore().byId(AppID);
		},

		back_to_main: function(oEvent) {
			jQuery.sap.require("sap.m.MessageBox");
			var vType;
			var tIDs;
			var oApp = this.get_app_obj("oApp");
			var oObj = oEvent.getSource();
			if (oApp !== undefined) {
				if (oObj.getId() === "oPageFour") {
					vType = "F";
				} else if (oObj.getId() === "oPageNine") {
					vType = "N";
				}
				tIDs = this.arrange_ids(vType);
				if (this.is_cell_filled(tIDs) === true) {
					sap.m.MessageBox.show(
						"Cells already filled, data will lost. Continue?", {
							icon: sap.m.MessageBox.Icon.INFORMATION,
							title: "My message box title",
							actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
							onClose: function(oAction) {
								if (oAction === sap.m.MessageBox.Action.NO) {
									return;
								} else {
									sap.ui.controller("Sudoku.controller.main").refresh_all_controls(vType);
									oApp = sap.ui.controller("Sudoku.controller.main").get_app_obj("oApp");
									oApp.back();
								}
							}
						}
					);
				} else {
					this.refresh_all_controls(vType);
					oApp.back();
				}
			}
		},
		

		get_select_option: function() {
			var oObj = sap.ui.getCore().byId("vInputCell");
			if (oObj !== undefined) {
				return oObj.getSelectedItemId();
			}
		},

		arrange_info: function(oEvent) {
			var oApp = this.get_app_obj("oApp");
			var oPage;
			var tIDs;
			var vType;
			var oLayout;
			var oBttnLayOut;
			if (oApp !== undefined) {
				vType = this.get_select_option();
				tIDs = this.arrange_ids(vType);
				if (this.is_cell_created(tIDs) === false) {
					if (vType === "F") {
						oPage = sap.ui.getCore().byId("oPageFour");
						oLayout = this.arrange_display(vType, tIDs);
					} else if (vType === "N") {
						oPage = sap.ui.getCore().byId("oPageNine");
						oLayout = this.arrange_display(vType, tIDs);
					}
					oBttnLayOut = this.add_play_button(vType);
					oLayout.addItem(oBttnLayOut);
					oPage.addContent(oLayout);
				}
				if (vType === "F") {
					oApp.to("oPageFour");
				} else if (vType === "N") {
					oApp.to("oPageNine");
				}

			}
		},

		is_cell_created: function(tIDs) {
			if (tIDs.length > 1) {
				if ((sap.ui.getCore().byId(tIDs[1].ID)) === undefined) {
					return false;
				} else {
					return true;
				}
			}
		},

		arrange_ids: function(nType) {
			var iType;
			var iLoop;
			var jLoop;
			var vID;
			var iEnd;
			var tID = [{
				ID: "ID"
			}];
			//NO	Box	Horizontal	Vertical
			var iCell = 1;
			var iBox = 1;
			if (nType === "F") {
				vID = "M4_";
				iType = 4;
				iEnd = 2;
			} else if (nType === "N") {
				vID = "M9_";
				iType = 9;
				iEnd = 3;
			}
			for (iLoop = 1; iLoop <= iType; iLoop++) {
				iBox = this.get_Box_id(iType, iLoop);
				for (jLoop = 1; jLoop <= iType; jLoop++) {
					var wID = {};
					wID["ID"] = vID.concat(iCell.toString().concat("_".concat(iBox.toString().concat("_".concat(iLoop.toString().concat("_".concat(
						jLoop.toString())))))));
					tID.push(wID);
					if ((jLoop % iEnd) === 0) {
						iBox++;
					}
					iCell++;
				}
			}
			return tID;
		},

		get_Box_id: function(nType, nRow) {
			if (nType === 4) {
				if (nRow === 1 || nRow === 2) {
					return 1;
				} else if (nRow === 3 || nRow === 4) {
					return 3;
				}
			} else if (nType === 9) {
				if (nRow === 1 || nRow === 2 || nRow === 3) {
					return 1;
				} else if (nRow === 4 || nRow === 5 || nRow === 6) {
					return 4;
				} else if (nRow === 7 || nRow === 8 || nRow === 9) {
					return 7;
				}
			}
		},

		arrange_display: function(nType, tIDs) {
			var vMainID;
			var vSubMainID;
			var vBoxID;
			var vSubBoxID;
			var vCellID;
			var iBox;
			var iLoop;
			var jLoop;
			var iEnd;
			var iRow = 1;
			var oBoxRow;
			var oBox;
			var iType;

			if (nType === "F") {
				iEnd = 2;
				iType = 4;
			} else if (nType === "N") {
				iEnd = 3;
				iType = 9;
			}
			iBox = iType;

			vMainID = "M".concat(nType.toString().concat("MAIN"));
			vSubMainID = "M".concat(nType.toString().concat("BOXROW"));
			vSubBoxID = "M".concat(nType.toString().concat("BOXROW"));
			vCellID = "M".concat(nType.toString().concat("CELL"));

			var oMainLayOut = new sap.m.FlexBox(vMainID, {
				alignItems: sap.m.FlexAlignItems.Center,
				justifyContent: sap.m.FlexJustifyContent.Center,
				direction: sap.m.FlexDirection.Column,
				displayInline: true,
				width: "100%",
				height: "100%"
			});

			vSubMainID = vSubMainID.concat("_".concat(iRow.toString()));
			oBoxRow = new sap.m.FlexBox(vSubMainID, {
				alignItems: sap.m.FlexAlignItems.Center,
				justifyContent: sap.m.FlexJustifyContent.Center,
				direction: sap.m.FlexDirection.Row
			});
			for (iLoop = 1; iLoop <= iBox; iLoop++) {
				var tBoxIDs = this.get_box_ids(iLoop, tIDs);
				oBox = this.create_box(tBoxIDs, iType, iLoop);
				oBoxRow.addItem(oBox);
				if ((iLoop % iEnd) === 0) {
					oMainLayOut.addItem(oBoxRow);
					iRow++;
					vSubMainID = vSubMainID.concat("_".concat(iRow.toString()));
					oBoxRow = new sap.m.FlexBox(vSubMainID, {
						alignItems: sap.m.FlexAlignItems.Center,
						justifyContent: sap.m.FlexJustifyContent.Center,
						direction: sap.m.FlexDirection.Row
					});
				}
			}
			return oMainLayOut;
		},

		get_box_ids: function(iBoxNo, tIDs) {
			var tID = [{
				ID: "ID"
			}];
			var iLoop;
			var vIDs;
			for (iLoop = 1; iLoop < tIDs.length; iLoop++) {
				vIDs = (tIDs[iLoop].ID).split("_");
				if (vIDs.length === 5 && iBoxNo === Number(vIDs[2])) {
					var wID = {};
					wID["ID"] = tIDs[iLoop].ID;
					tID.push(wID);
				}
			}
			return tID;
		},

		create_box: function(tIDs, nType, nBoxNo) {
			var vBoxID = "M".concat(nType.toString().concat("BOX".concat(nBoxNo.toString())));
			var iEnd;
			var iLoop;
			var tInfo;
			var iRow;
			var vRowID;
			var oCellInput;
			var oRowLayOut;
			var oBoxLayOut = new sap.m.FlexBox(vBoxID, {
				alignItems: sap.m.FlexAlignItems.Center,
				justifyContent: sap.m.FlexJustifyContent.Center,
				direction: sap.m.FlexDirection.Column,
				width: "100%",
				height: "100%"
			}).addStyleClass('cell_text');

			if (nType === 4) {
				iEnd = 2;
			} else if (nType === 9) {
				iEnd = 3;
			}
			for (iLoop = 1; iLoop < tIDs.length; iLoop++) {
				tInfo = (tIDs[iLoop].ID).split("_");
				if (iRow === 0 || iRow !== Number(tInfo[3])) {
					iRow = Number(tInfo[3]);
					vRowID = "M".concat(nType.toString().concat("_ROW".concat(tInfo[3].concat("_BOX".concat(tInfo[2].toString())))));
					oRowLayOut = new sap.m.FlexBox(vRowID, {
						alignItems: sap.m.FlexAlignItems.Center,
						justifyContent: sap.m.FlexJustifyContent.Center,
						direction: sap.m.FlexDirection.Row
					});
					oBoxLayOut.addItem(oRowLayOut);
				}
				oCellInput = new sap.m.Input(tIDs[iLoop].ID, {
					type: sap.m.InputType.Number,
					maxLength: 1,
					fieldWidth: "15px"
				}).addStyleClass("cell_gap");
				oCellInput.setWidth("40px");
				oRowLayOut.addItem(oCellInput);
			}
			return oBoxLayOut;
		},

		add_play_button: function(nType) {
			var vBttnSet = "oBttnSet_".concat(nType);
			var vBttnCheck = "oBttnCheck_".concat(nType);
			var vBttnRefresh = "oBttnRefresh_".concat(nType);
			var vBttnSolve = "oBttnSolve_".concat(nType);
			var vBttnReSet = "vBttnReSet".concat(nType);
			if (sap.ui.getCore().byId(vBttnSet) === undefined) {
				var oBttnSet = new sap.m.Button(vBttnSet, {
					text: "Set Initial Values",
					icon: "sap-icon://edit",
					width: "125px",
					press: function(oEvent) {
						sap.ui.controller("Sudoku.controller.main").oBttnSet_press(oEvent);
					}
				});

				var oBttnCheck = new sap.m.Button(vBttnCheck, {
					text: "Check",
					icon: "sap-icon://accept",
					width: "125px",
					press: function(oEvent) {
						sap.ui.controller("Sudoku.controller.main").oBttnCheck_press(oEvent);
					}
				});
				oBttnCheck.setVisible(false);

				var oBttnRefresh = new sap.m.Button(vBttnRefresh, {
					text: "Refresh",
					icon: "sap-icon://synchronize",
					width: "125px",
					press: function(oEvent) {
						sap.ui.controller("Sudoku.controller.main").oBttnRefresh_press(oEvent);
					}
				});

				var oBttnReSet = new sap.m.Button(vBttnReSet, {
					text: "Reset",
					icon: "sap-icon://undo",
					width: "125px",
					press: function(oEvent) {
						sap.ui.controller("Sudoku.controller.main").oBttnReSet_press(oEvent);
					}
				});
				oBttnReSet.setVisible(false);

				var oBttnSolve = new sap.m.Button(vBttnSolve, {
					text: "Show Result",
					icon: "sap-icon://show",
					width: "125px",
					press: function(oEvent) {
						sap.ui.controller("Sudoku.controller.main").oBttnSolve_press(oEvent);
					}
				});
				oBttnSolve.setVisible(false);

				var oFlexAction = new sap.m.FlexBox({
					alignItems: sap.m.FlexAlignItems.Center,
					justifyContent: sap.m.FlexJustifyContent.Center,
					direction: sap.m.FlexDirection.Row
				});
				oFlexAction.addItem(oBttnSet);
				oFlexAction.addItem(oBttnCheck);
				oFlexAction.addItem(oBttnRefresh);
				oFlexAction.addItem(oBttnSolve);
				oFlexAction.addItem(oBttnReSet);

				return oFlexAction;
			}
		},

		oBttnSet_press: function(oEvent) {
			var oBj = oEvent.getSource();
			var iType = 0;
			var vtype;
			var bGet;
			if (this.get_select_option() === "F") {
				iType = 4;
				vtype = "F";
			} else {
				iType = 9;
				vtype = "N";
			}
			var vBttnCheck = "oBttnCheck_".concat(vtype);
			var vBttnSolve = "oBttnSolve_".concat(vtype);
			var vBttnReSet = "vBttnReSet".concat(vtype);
			bGet = this.is_value_set(vtype);
			if (bGet === false) {
				sap.m.MessageToast.show("All box should contains some value!!!");
			} else {
				oBj.setVisible(false);
				sap.ui.getCore().byId(vBttnCheck).setVisible(true);
				sap.ui.getCore().byId(vBttnSolve).setVisible(true);
				sap.ui.getCore().byId(vBttnReSet).setVisible(true);
			}
		},

		oBttnCheck_press: function(oEvent) {
			var vType;
			var tIDs;
			var iSum = 0;
			var iErr = 0;
			var sMsg;
			vType = this.get_select_option();
			if (vType === "F") {
				iSum = 10;
			} else if (vType === "N") {
				iSum = 45;
			}
			tIDs = this.arrange_ids(vType);
			if (this.is_cell_filled(tIDs) === false) {
				sMsg = "Fill all cell value to check result!!!!";
				sap.m.MessageToast.show(sMsg);
				return;
			}

			iErr = this.is_box_correct(vType, tIDs, iSum);
			if (iErr !== 0) {
				sMsg = "Values are not correct in ".concat(iErr.toString().concat(" Box!!!"));
				sap.m.MessageToast.show(sMsg);
				return;
			}

			iErr = this.is_Line_correct(vType, tIDs, iSum, "H");
			if (iErr !== 0) {
				sMsg = "Values are not correct in horizontal ".concat(iErr.toString().concat(" Line!!!"));
				sap.m.MessageToast.show(sMsg);
				return;
			}

			iErr = this.is_Line_correct(vType, tIDs, iSum, "V");
			if (iErr !== 0) {
				sMsg = "Values are not correct in vertical ".concat(iErr.toString().concat(" Line!!!"));
				sap.m.MessageToast.show(sMsg);
				return;
			}

			sap.m.MessageToast.show("Winnnnneeeeeerrrrrrrr!!!!!!");
		},

		oBttnRefresh_press: function(oEvent) {
			var vType;
			vType = this.get_select_option();
			this.refresh_all_controls(vType);
		},

		refresh_all_controls: function(vType) {
			var vBttnCheck = "oBttnCheck_".concat(vType);
			var vBttnSolve = "oBttnSolve_".concat(vType);
			var vBttnSet = "oBttnSet_".concat(vType);
			var vBttnReSet = "vBttnReSet".concat(vType);
			if (sap.ui.getCore().byId(vBttnCheck) !== undefined) {
				sap.ui.getCore().byId(vBttnCheck).setVisible(false);
				sap.ui.getCore().byId(vBttnSolve).setVisible(false);
				sap.ui.getCore().byId(vBttnSet).setVisible(true);
				sap.ui.getCore().byId(vBttnReSet).setVisible(false);
				this.refresh_controls(vType);
			}
		},

		oBttnReSet_press: function(oEvent) {
			var vType;
			var iLoop;
			var tIDs;
			vType = this.get_select_option();
			tIDs = this.arrange_ids(vType);
			for (iLoop = 0; iLoop < tIDs.length; iLoop++) {
				if (sap.ui.getCore().byId(tIDs[iLoop].ID) !== undefined) {
					if (sap.ui.getCore().byId(tIDs[iLoop].ID).getEditable() === true) {
						sap.ui.getCore().byId(tIDs[iLoop].ID).setValue("");
					}
				}
			}
		},

		oBttnSolve_press: function(oEvent) {
			var tValues = [{
				ID: "ID",
				VAL: ""
			}];
			var vType;
			var nType;
			var tIDs;
			var sMsg;
			var iLen1 = 0;
			var iLen2 = 0;
			var iSum = 0;

			vType = this.get_select_option();
			if (vType === "F") {
				iSum = 10;
				nType = 4;
			} else if (vType === "N") {
				iSum = 45;
				nType = 9;
			}
			tIDs = this.arrange_ids(vType);
			if (this.is_cell_filled(tIDs) === false) {
				sMsg = "Fill Initial cell value to check result!!!!";
				sap.m.MessageToast.show(sMsg);
				return;
			}
			do {
				tValues = this.get_cell_approx_values(nType, tIDs);

				if (iLen1 === 0) {
					iLen1 = tValues.length;
				} else {
					iLen2 = tValues.length;
					if (iLen1 !== iLen2) {
						iLen1 = iLen2;
						iLen2 = 0;
					} else {
						break;
					}
				}
			}
			while (tValues.length > 1);
			if (tValues.length > 1) {
				this.set_first_2_values(tValues, nType, tIDs, 0);
			}
		},

		is_value_set: function(vType) {
			var tIDs = this.arrange_ids(vType);
			var iLoop;
			var jLoop;
			var iType;
			var tInfo;
			var bGet = false;
			if (vType === "F") {
				iType = 4;
			} else if (vType === "N") {
				iType = 9;
			}
			for (iLoop = 1; iLoop <= iType; iLoop++) {
				bGet = false;
				for (jLoop = 1; jLoop < tIDs.length; jLoop++) {
					if (sap.ui.getCore().byId(tIDs[jLoop].ID) !== undefined) {
						tInfo = tIDs[jLoop].ID.split("_");
						if (tInfo.length === 5) {
							if (Number(tInfo[2]) === iLoop) {
								if (sap.ui.getCore().byId(tIDs[jLoop].ID).getValue() !== "") {
									bGet = true;
									break;
								}
							}
						}
					}
				}
				if (bGet === false) {
					break;
				}
			}
			if (bGet === true) {
				for (iLoop = 1; iLoop < tIDs.length; iLoop++) {
					if (sap.ui.getCore().byId(tIDs[iLoop].ID) !== undefined) {
						if (sap.ui.getCore().byId(tIDs[iLoop].ID).getValue() !== "") {
							bGet = true;
							sap.ui.getCore().byId(tIDs[iLoop].ID).setEditable(false);
						}
					}
				}
			}
			return bGet;
		},

		refresh_controls: function(vType) {
			var tIDs = this.arrange_ids(vType);
			var iLoop;
			for (iLoop = 1; iLoop < tIDs.length; iLoop++) {
				if (sap.ui.getCore().byId(tIDs[iLoop].ID) !== undefined) {
					sap.ui.getCore().byId(tIDs[iLoop].ID).setValue() !== "";
					sap.ui.getCore().byId(tIDs[iLoop].ID).setEditable(true);
				}
			}
		},

		is_cell_filled: function(tIDs) {
			var iLoop;
			var bFill = false;
			for (iLoop = 1; iLoop < tIDs.length; iLoop++) {
				if (sap.ui.getCore().byId(tIDs[iLoop].ID) !== undefined) {
					if (sap.ui.getCore().byId(tIDs[iLoop].ID).getValue() === "") {
						bFill = false;
					} else {
						bFill = true;
						break;
					}
				}
			}
			return bFill;
		},

		is_box_correct: function(vType, tIDs, iSum) {
			var tBoxIDs;
			var iTotal = 0;
			var iLoop;
			var jLoop;
			var iType;
			if (vType === "F") {
				iType = 4;
			} else if (vType === "N") {
				iType = 9;
			}
			for (iLoop = 1; iLoop <= iType; iLoop++) {
				tBoxIDs = this.get_box_ids(iLoop, tIDs);
				iTotal = 0;
				for (jLoop = 1; jLoop < tBoxIDs.length; jLoop++) {
					if (sap.ui.getCore().byId(tBoxIDs[jLoop].ID) !== undefined) {
						iTotal = iTotal + Number(sap.ui.getCore().byId(tBoxIDs[jLoop].ID).getValue());
					}
				}
				if (iTotal !== iSum) {
					return iLoop;
				}
			}
			return 0;
		},

		is_Line_correct: function(vType, tIDs, iSum, vHV) {
			var iLoop;
			var jLoop;
			var iTotal;
			var iType;
			var sInfo;
			var iLine;
			if (vType === "F") {
				iType = 4;
			} else if (vType === "N") {
				iType = 9;
			}
			for (iLoop = 1; iLoop <= iType; iLoop++) {
				iTotal = 0;
				for (jLoop = 1; jLoop < tIDs.length; jLoop++) {
					sInfo = (tIDs[jLoop].ID).split("_");
					if (sInfo.length === 5) {
						if (vHV === "H") {
							iLine = Number(sInfo[3]);
						} else if (vHV === "V") {
							iLine = Number(sInfo[4]);
						}
						if (iLine === iLoop) {
							if (sap.ui.getCore().byId(tIDs[jLoop].ID) !== undefined) {
								iTotal = iTotal + Number(sap.ui.getCore().byId(tIDs[jLoop].ID).getValue());
							}
						}
					}
				}
				if (iTotal !== iSum) {
					return iLoop;
				}
			}
			return 0;
		},

		get_cell_approx_values: function(nType, tIDs) {
			var tValues = [{
				ID: "ID",
				VAL: ""
			}];
			var iLoop;
			var iBox;
			var iHor;
			var iVer;
			var tInfo;
			var vAppValue;
			var vBoxValues;
			var vHorValues;
			var vVerValue;
			var vCommon;

			if (nType === 4) {
				vAppValue = "1234";
			} else if (nType === 9) {
				vAppValue = "123456789";
			}

			for (iLoop = 1; iLoop < tIDs.length; iLoop++) {
				if (sap.ui.getCore().byId(tIDs[iLoop].ID) !== undefined) {
					var wValue = {};
					if (sap.ui.getCore().byId(tIDs[iLoop].ID).getValue() === "") {
						tInfo = sap.ui.getCore().byId(tIDs[iLoop].ID).getId().split("_");
						if (tInfo.length === 5) {
							iBox = Number(tInfo[2]);
							iHor = Number(tInfo[3]);
							iVer = Number(tInfo[4]);
							vBoxValues = this.get_box_approx_value(tIDs, iBox, vAppValue);
							vHorValues = this.get_rows_approx_value(tIDs, iHor, "H", vAppValue);
							vVerValue = this.get_rows_approx_value(tIDs, iVer, "V", vAppValue);
							vCommon = this.get_final_cell_value(nType, vBoxValues, vHorValues, vVerValue);
							if (vCommon.length === 1) {
								sap.ui.getCore().byId(tIDs[iLoop].ID).setValue(vCommon);
							} else {
								wValue["ID"] = tIDs[iLoop].ID;
								wValue["VAL"] = vCommon;
								tValues.push(wValue);
							}
						}
					}
				}
			}
			return tValues;
		},

		get_box_approx_value: function(tIDs, iBox, vAppValue) {
			var iLoop;
			var tInfo;
			var vValue = "";
			for (iLoop = 1; iLoop < tIDs.length; iLoop++) {
				tInfo = sap.ui.getCore().byId(tIDs[iLoop].ID).getId().split("_");
				if (tInfo.length === 5) {
					if (Number(tInfo[2]) === iBox) {
						if (sap.ui.getCore().byId(tIDs[iLoop].ID) !== undefined) {
							if (sap.ui.getCore().byId(tIDs[iLoop].ID).getValue() !== "") {
								vAppValue = vAppValue.replace(sap.ui.getCore().byId(tIDs[iLoop].ID).getValue(), "");
							}
						}
					}
				}
			}
			return vAppValue;
		},

		get_rows_approx_value: function(tIDs, iHV, vHV, vAppValue) {
			var iLoop;
			var tInfo;
			var vValue = "";
			var iRow = 0;
			for (iLoop = 1; iLoop < tIDs.length; iLoop++) {
				tInfo = sap.ui.getCore().byId(tIDs[iLoop].ID).getId().split("_");
				if (tInfo.length === 5) {
					if (vHV === "H") {
						iRow = Number(tInfo[3]);
					} else if (vHV === "V") {
						iRow = Number(tInfo[4]);
					}
					if (iHV === iRow) {
						if (sap.ui.getCore().byId(tIDs[iLoop].ID) !== undefined) {
							if (sap.ui.getCore().byId(tIDs[iLoop].ID).getValue() !== "") {
								vAppValue = vAppValue.replace(sap.ui.getCore().byId(tIDs[iLoop].ID).getValue(), "");
							}
						}
					}
				}
			}
			return vAppValue;
		},

		get_final_cell_value: function(nType, vBoxValues, vHorValues, vVerValue) {
			var vCommon = "";
			var iLoop;

			for (iLoop = 1; iLoop <= nType; iLoop++) {
				if (vBoxValues.length > (vBoxValues.replace(iLoop.toString(), "")).length) {
					if (vHorValues.length > (vHorValues.replace(iLoop.toString(), "")).length) {
						if (vVerValue.length > (vVerValue.replace(iLoop.toString(), "")).length) {
							vCommon = vCommon.concat(iLoop.toString());
						}
					}
				}
			}
			return vCommon;
		},

		set_first_2_values: function(tValues, nType, tIDs, iPos) {
			var wValues = [{
				ID: "ID",
				VAL: ""
			}];
			var tKeep;
			var iLoop;
			var iLen1 = 0;
			var iLen2 = 0;
			var iNewPos = -1;

			for (iLoop = 1; iLoop < tValues.length; iLoop++) {
				if (tValues[iLoop].VAL.length === 2) {
					if (sap.ui.getCore().byId(tValues[iLoop].ID) !== undefined) {
						if (sap.ui.getCore().byId(tValues[iLoop].ID).getValue() === "") {
							sap.ui.getCore().byId(tValues[iLoop].ID).setValue(tValues[iLoop].VAL.charAt(iPos));
							break;
						}
					}
				}
			}
			do {
				wValues = this.get_cell_approx_values(nType, tIDs);
				if (this.is_contains_blank(wValues) === true) {
					this.revert_changes(tValues);
					if (iPos === 0) {
						iNewPos = 1;
					} else {
						iNewPos = 0;
					}
					break;
				}
				if (iLen1 === 0) {
					iLen1 = wValues.length;
				} else {
					iLen2 = wValues.length;
					if (iLen1 !== iLen2) {
						iLen1 = iLen2;
						iLen2 = 0;
					} else {
						break;
					}
				}
			}
			while (wValues.length > 1);
			if (iNewPos !== -1) {
				this.set_first_2_values(tValues, nType, tIDs, iNewPos);
			} else if (tValues.length > 1) {
				this.set_first_2_values(wValues, nType, tIDs, 0);
			}
		},

		is_contains_blank: function(tValues) {
			var iLoop;
			var bRes = false;
			for (iLoop = 1; iLoop < tValues.length; iLoop++) {
				if (tValues[iLoop].VAL === "") {
					bRes = true;
					break;
				}
			}
			return bRes;
		},

		revert_changes: function(tValues) {
			var iLoop;
			for (iLoop = 1; iLoop < tValues.length; iLoop++) {
				if (sap.ui.getCore().byId(tValues[iLoop].ID) !== undefined) {
					sap.ui.getCore().byId(tValues[iLoop].ID).setValue("");
				}
			}
		}
	});

});