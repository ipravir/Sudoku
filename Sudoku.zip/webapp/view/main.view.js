sap.ui.jsview("Sudoku.view.main", {

	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf controller.main
	 */
	getControllerName: function() {
		return "Sudoku.controller.main";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away.
	 * @memberOf controller.main
	 */
	createContent: function(oController) {

		var oFlexMainCon = new sap.m.FlexBox("oFlexMainCon", {
			alignItems: sap.m.FlexAlignItems.Center,
			justifyContent: sap.m.FlexJustifyContent.Center,
			direction: sap.m.FlexDirection.Column,
			width: "100%",
			height: "100%"
		});

		//Comtainer
		var oFlexContainer = new sap.m.FlexBox("oFlexContainer", {
			alignItems: sap.m.FlexAlignItems.Center,
			justifyContent: sap.m.FlexJustifyContent.Center
		});

		//Information label
		var oLblCell = new sap.m.Label({
			design: sap.m.LabelDesign.Standard,
			text: "No of Cell Matrix",
			textAlign: sap.ui.core.TextAlign.Center,
			required: true,
			width: "200px"
		});
		oFlexContainer.addItem(oLblCell);

		//Cell Matrix number input
		var vInputCell = new sap.ui.commons.DropdownBox("vInputCell"); //.addStyleClass('input_text');
		var oItem4 = new sap.ui.core.ListItem("F");
		oItem4.setText("4 Cell Matrix");
		vInputCell.addItem(oItem4);
		var oItem9 = new sap.ui.core.ListItem("N");
		oItem9.setText("9 Cell Matrix");
		vInputCell.addItem(oItem9);
		vInputCell.setPlaceholder("Matrix No");
		oFlexContainer.addItem(vInputCell);

		//Button Comtainer
		var oFlexBttnContainer = new sap.m.FlexBox("oFlexBttnContainer", {
			alignItems: sap.m.FlexAlignItems.Center,
			justifyContent: sap.m.FlexJustifyContent.Center
		});

		var oBttnEnter = new sap.m.Button({
			text: "Arrange No.",
			width: "150px",
			type: sap.m.ButtonType.Accept,
			press: function(oEvent) {
				oController.arrange_info(oEvent);
			}
		}).addStyleClass('bttn_accept');

		var oBttnCancel = new sap.m.Button({
			text: "Cancel",
			width: "150px",
			type: sap.m.ButtonType.Reject,
			press: function(oEvent) {
				oController.close_app(oEvent);
			}
		}).addStyleClass('bttn_cancel');

		oFlexBttnContainer.addItem(oBttnEnter);
		oFlexBttnContainer.addItem(oBttnCancel);

		oFlexMainCon.addItem(oFlexContainer);
		oFlexMainCon.addItem(oFlexBttnContainer);

		var oPage = new sap.m.Page("oPage", {
			title: "{i18n>title}",
			content: [oFlexMainCon]
		}).addStyleClass('login_page');

		var oPageFour = new sap.m.Page("oPageFour", {
			title: "{i18n>fourtitle}",
			showNavButton: true,
			showSubHeader: false,
			enableScrolling: false,
			navButtonType: sap.m.ButtonType.Back,
			showFooter: false,
			navButtonPress: function(oEvent) {
				oController.back_to_main(oEvent);
			}
		}).addStyleClass("play_page");
		var oPageNine = new sap.m.Page("oPageNine", {
			title: "{i18n>ninetitle}",
			showNavButton: true,
			showSubHeader: false,
			enableScrolling: false,
			navButtonType: sap.m.ButtonType.Back,
			showFooter: false,
			navButtonPress: function(oEvent) {
				oController.back_to_main(oEvent);
			}
		}).addStyleClass("play_page");

		var oApp = new sap.m.App("oApp", {
			initialPage: "oPage"
		});

		var oLink = new sap.m.Link("main_page", {
			text: "By Praveer Kumar Sen",
			href: "https://scn.sap.com/people/praveerkumar.sen",
			wrapping: true,
			emphasized: true
		});

		oPage.addHeaderContent(oLink);
		oApp.addPage(oPage);

		oLink = new sap.m.Link("nine_page", {
			text: "By Praveer Kumar Sen",
			href: "https://scn.sap.com/people/praveerkumar.sen",
			wrapping: true,
			emphasized: true
		});
		oPageNine.addHeaderContent(oLink);
		oApp.addPage(oPageNine);

		oLink = new sap.m.Link("four_page", {
			text: "By Praveer Kumar Sen",
			href: "https://scn.sap.com/people/praveerkumar.sen",
			wrapping: true,
			emphasized: true
		});
		oPageFour.addHeaderContent(oLink);
		oApp.addPage(oPageFour);
		return oApp;
	}

});